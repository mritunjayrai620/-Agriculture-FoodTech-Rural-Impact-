import math

class AgriLogisticsOptimizer:
    def __init__(self, hub_location):
        """
        hub_location: (lat, lon) for the central warehouse or market.
        """
        self.hub = hub_location
        self.farm_pickups = []

    def add_farm(self, farm_id, location, load_weight):
        """
        Adds a farm to the daily route.
        location: (lat, lon)
        load_weight: weight in kg (to check truck capacity)
        """
        self.farm_pickups.append({
            "id": farm_id,
            "coords": location,
            "weight": load_weight
        })

    def calculate_distance(self, p1, p2):
        """Standard Euclidean distance (for simplified demo)."""
        return math.sqrt((p1[0]-p2[0])**2 + (p1[1]-p2[1])**2)

    def optimize_route(self, truck_capacity):
        """
        Greedy Algorithm: Find the next closest farm that fits in the truck.
        """
        unvisited = self.farm_pickups[:]
        current_location = self.hub
        route = []
        total_load = 0
        total_distance = 0

        while unvisited:
            # Find the nearest farm that fits current capacity
            next_stop = None
            closest_dist = float('inf')

            for farm in unvisited:
                dist = self.calculate_distance(current_location, farm['coords'])
                if dist < closest_dist and (total_load + farm['weight'] <= truck_capacity):
                    closest_dist = dist
                    next_stop = farm

            if next_stop:
                route.append(next_stop['id'])
                total_load += next_stop['weight']
                total_distance += closest_dist
                current_location = next_stop['coords']
                unvisited.remove(next_stop)
            else:
                # Truck full or no reachable farms
                break

        # Return to Hub
        total_distance += self.calculate_distance(current_location, self.hub)
        
        return {
            "route_order": route,
            "total_distance": round(total_distance, 2),
            "utilized_capacity": total_load,
            "efficiency": f"{(total_load/truck_capacity)*100}%"
        }

# --- Example Usage ---
if __name__ == "__main__":
    # Central Market at (0,0)
    optimizer = AgriLogisticsOptimizer(hub_location=(0, 0))

    # Adding remote farms
    optimizer.add_farm("Farm_A", (1, 2), 500)
    optimizer.add_farm("Farm_B", (2, 2), 300)
    optimizer.add_farm("Farm_C", (5, 1), 400)

    # Truck with 1000kg capacity
    result = optimizer.optimize_route(truck_capacity=1000)
    
    print(f"Optimized Route: {result['route_order']}")
    print(f"Total Distance: {result['total_distance']} km")
    print(f"Capacity Used: {result['utilized_capacity']} kg")